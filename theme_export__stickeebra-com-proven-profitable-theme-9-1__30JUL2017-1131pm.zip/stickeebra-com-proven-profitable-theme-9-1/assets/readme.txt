Licenses Used:
/* jQuery UI - v1.10.4 - 2014-04-14 http://jqueryui.com Includes: jquery.ui.core.js, jquery.ui.widget.js, jquery.ui.mouse.js, jquery.ui.position.js, jquery.ui.autocomplete.js, jquery.ui.menu.js * Copyright 2014 jQuery Foundation and other contributors; Licensed MIT */
/* ScrollToFixed - https://github.com/bigspotteddog/ScrollToFixed - Copyright (c) 2011 Joseph Cava-Lynch - MIT license*/
/* imagesLoaded PACKAGED v3.1.0 * JavaScript is all like "You images are done yet or what?"* MIT License*/
/* hoverIntent v1.8.0 // 2014.06.29 // jQuery v1.9.1+ * http://cherne.net/brian/resources/jquery.hoverIntent.html * * You may use hoverIntent under the terms of the MIT license. Basically that * means you are free to use hoverIntent as long as this header is left intact * Copyright 2007, 2014 Brian Cherne */
/* Modernizr 2.6.2 (Custom Build) | MIT & BSD Build: http://modernizr.com/download/#-touch-shiv-cssclasses-teststyles-prefixes-load */
/* fancyBox v2.1.5 fancyapps.com | fancyapps.com/fancybox/#license */
/* jQuery FlexSlider v2.2.2 * Copyright 2012 WooThemes * Contributing Author: Tyler Smith */
/* jQuery flexslider extension * Original author: @markirby * Licensed under the MIT license */